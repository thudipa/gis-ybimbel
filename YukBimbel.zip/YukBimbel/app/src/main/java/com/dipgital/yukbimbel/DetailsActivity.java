package com.dipgital.yukbimbel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {
    public static String nama,tipe,alamat;
    public static int gambar;
    TextView tv_nama,tv_alamat,tv_tipe;
    ImageView iv_header_details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        tv_nama=findViewById(R.id.tv_nama);
        tv_tipe=findViewById(R.id.tv_tipe);
        tv_alamat=findViewById(R.id.tv_alamat);

        tv_nama.setText(nama);
        tv_tipe.setText(tipe);
        tv_alamat.setText(alamat);


    }
}
