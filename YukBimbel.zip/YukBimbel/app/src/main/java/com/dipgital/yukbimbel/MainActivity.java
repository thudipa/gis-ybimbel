package com.dipgital.yukbimbel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView imageViewMaps;
    ImageView imageViewList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageViewMaps=findViewById(R.id.btn_maps);
        //imageViewList=findViewById(R.id.btn_list);

        imageViewMaps.setOnClickListener(this);
        //imageViewList.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        Intent moveAkademis = new Intent(MainActivity.this,MapsActivity.class);
        startActivities(new Intent[]{moveAkademis});

        //Intent moveList = new Intent(MainActivity.this,ListActivity.class);
        //startActivities(new Intent[]{moveList});

    }
}
