-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 13 Jun 2021 pada 09.06
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ybimbel`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bimble`
--

CREATE TABLE `bimble` (
  `id` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `tipe` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `bimble`
--

INSERT INTO `bimble` (`id`, `nama`, `tipe`, `alamat`, `latitude`, `longitude`, `gambar`) VALUES
(1, 'Prima Edu Pendamping Belajar', 'akademis', 'Taman Griya, Jl.Batur Raya No.45, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', -8.788479244936099, 115.18734088918012, 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.youtube.com%2Fc%2Fprimagamaindonesia&psig=AOvVaw1hmriwUVenBY9PLg5_7hxG&ust=1623313042792000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMjy6b-OivECFQAAAAAdAAAAABAD'),
(2, 'Futsal Center', 'nonakademis', 'Perumahan Kori Nuansa, Jalan Kori Jl. Nuansa Barat IV, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', -8.799390617209681, 115.18170466482862, 'https://bit.ly/3isGign'),
(3, 'Calistung (Baca Tulis Hitung)', 'akademis', 'Jl. Raya Kampus Unud No.19Jimbaran, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', -8.787241736010792, 115.17771952462692, 'bit.ly/'),
(4, 'Guatarlis', 'nonakademis', 'Gg. Seraya Murthi I, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', -8.791376799096765, 115.18754835489857, 'bit.ly/'),
(5, 'Mari Belajar Matematika', 'akademis', 'Gg. Buanasari 8-88, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', -8.7940775, 115.1569302, 'bit.ly/'),
(6, 'Bimbel bu Diva', 'akademis', 'Jl. Kubung Batu Raya 20, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', -8.787195, 115.189312, 'bit.ly/'),
(7, 'Ganesha Operation Ungasan', 'akademis', 'Jl. bali cliff Ungasan, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', -8.820547, 115.161785, 'bit.ly/'),
(8, 'Ganesha Operation Jimbaran', 'akademis', 'Jl. Bypass Ngurah Rai, Jimbaran, Kec. Kuta Sel., Kabupaten Badung, Bali 80361', -8.78259419772696, 115.18935104230601, 'bit.ly/'),
(9, 'Primagama Kuta', 'akademis', 'Jl. Kalianget No.2b, Kuta, Kabupaten Badung, Bali 80361', -8.722796323031604, 115.17681223255231, 'bit.ly/'),
(10, 'Ganesha Operation Sesetan', 'akademis', 'Jl. Raya Sesetan No.186, Sesetan, Denpasar Selatan, Kota Denpasar, Bali 80225', -8.69275883078042, 115.21899831830764, 'bit.ly/'),
(11, 'Ganesha Solution', 'akademis', 'No., Jl. Kerta Dalem XXI, Sidakarya, Denpasar Selatan, Kota Denpasar, Bali 80224', -8.69275883078042, 115.23513448613178, 'bit.ly/'),
(12, 'Easy and Fast', 'akademis', 'Jl. Tukad Balian No.111A, Renon, Denpasar Selatan, Kota Denpasar, Bali 80226', -8.68557290477135, 115.24225073245739, 'bit.ly/'),
(13, 'Easy Music', 'nonakademis', 'Jl. Pulau Kawe No.61, Pedungan, Denpasar Selatan, Kota Denpasar, Bali 80114', -8.681506325500328, 115.2070815740997, 'bit.ly/'),
(14, 'Ringcoustik', 'nonakademis', 'Jl. Gn. Batok IV No.22, Tegal Harum, Kec. Denpasar Bar., Kota Denpasar, Bali 80119', -8.663610134635851, 115.1979858313812, 'bit.ly/'),
(15, 'Mayorta', 'nonakademis', 'Jl. Tukad Citarum No.42B, Panjer, Denpasar Selatan, Kota Denpasar, Bali 80232', -8.681822898543055, 115.23431593378483, 'bit.ly/'),
(16, 'Melodia', 'nonakademis', 'Gedung Bali White House, Jl. Dewi Sri No.23, Legian, Kuta, Kota Denpasar, Bali 80361', -8.705017303770564, 115.17731879457638, 'bit.ly/');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bimble`
--
ALTER TABLE `bimble`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bimble`
--
ALTER TABLE `bimble`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
